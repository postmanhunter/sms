# 每小时处理一次分表相关
0 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Order.autoGenOrderTables >> /usr/share/nginx/html/www/webapi/Runtime/Order.autoGenOrderTables.log 2>&1

# 封盘开奖
* * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=kuaileshifen >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.kuaileshifen.log 2>&1
* * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=kuaisan >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.kuaisan.log 2>&1
* * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=liuhecai >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.liuhecai.log 2>&1
* * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=saiche >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.saiche.log 2>&1
* * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=shishicai >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.shishicai.log 2>&1
* * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=shiyixuanwu >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.shiyixuanwu.log 2>&1
* * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=xingyunnongchang >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.xingyunnongchang.log 2>&1

*/3 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=sfkuaileshifen >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.sfkuaileshifen.log 2>&1
*/3 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=sfkuaisan >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.sfkuaisan.log 2>&1
*/3 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=sfliuhecai >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.sfliuhecai.log 2>&1
*/3 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=sfsaiche >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.sfsaiche.log 2>&1
*/3 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=sfshishicai >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.sfshishicai.log 2>&1
*/3 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=sfshiyixuanwu >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.sfshiyixuanwu.log 2>&1
*/3 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=sfxingyunnongchang >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.sfxingyunnongchang.log 2>&1

*/5 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=wfkuaileshifen >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.wfkuaileshifen.log 2>&1
*/5 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=wfkuaisan >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.wfkuaisan.log 2>&1
*/5 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=wfliuhecai >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.wfliuhecai.log 2>&1
*/5 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=wfsaiche >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.wfsaiche.log 2>&1
*/5 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=wfshishicai >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.wfshishicai.log 2>&1
*/5 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=wfshiyixuanwu >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.wfshiyixuanwu.log 2>&1
*/5 * * * * php /usr/share/nginx/html/www/webapi/Commands/games.php -s Drawing.OneMin --game=wfxingyunnongchang >> /usr/share/nginx/html/www/webapi/Runtime/Drawing.OneMin.wfxingyunnongchang.log 2>&1