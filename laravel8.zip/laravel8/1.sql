select sms;
truncate table send_list;