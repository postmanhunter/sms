<?php
namespace App\Http\Controllers\Test;

use App\Http\Controllers\Apis;


class DevelopController extends Apis
{
    function develop(){
        
    }
    
    function develop1(){
        
    }
    function master(){
        
    }
}