<?php

namespace App\Http\Controllers\Test;

class FeatureController extends Apis
{
    function feature(){
        
    }
}