<?php

namespace App\Http\Controllers\Test;

use App\Helper\RsaHelper;
use App\Helper\LockHelper;
use App\Helper\RabbitmqHelper;
use App\Http\Controllers\Apis;
use App\Models\Test\TestModel;
use App\Models\Test\OrderModel;
use App\Http\Resources\Paginate;
use Longman\TelegramBot\Request;
use Longman\TelegramBot\Telegram;
use App\Http\Requests\Test\TestRequest;
use Symfony\Component\String\UnicodeString;
class TestController extends Apis
{
    const PUBLIC_KEY = "-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC1mgbM1p0FfIZ2GS7rasqJ1hYy
HNXfVQ5T/zD20j3ioyvRQWD+D/A6EWCcNzm9z15F9yxmXBCg/mfOAaOWtRDgoLdt
8qh2J5f88iQom7MJ7PaB4tHc8LyMe+Z/0oOZp4lFpc0E3LgYOExlyBJoiql35A8j
g4cKbQUYLFEjaxERMwIDAQAB
-----END PUBLIC KEY-----";
    const PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----
MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALWaBszWnQV8hnYZ
LutqyonWFjIc1d9VDlP/MPbSPeKjK9FBYP4P8DoRYJw3Ob3PXkX3LGZcEKD+Z84B
o5a1EOCgt23yqHYnl/zyJCibswns9oHi0dzwvIx75n/Sg5mniUWlzQTcuBg4TGXI
EmiKqXfkDyODhwptBRgsUSNrEREzAgMBAAECgYB301EHWdiz5Q2n4UgHSCiqOFve
5w3r1eilXe4F/oWdBIOGCHiiSwv8lLjFet8bsjeHPOfMBpVmVVdTI9u4NnMSV0Wu
Lx8Bkpi5aObG7okjMzyeAJh9yIBA101YDFPcD4LPQGFb3FOwDSXwciGgYhWT2ama
pEeOuIE0iM8njr+HWQJBAOg/0Qf4FfAjPUxIJv/NenHV1FHfjp1gXgjpCzaRWRGM
DbHCHKaORETmUDP8ZDIDuFnGmeEOxiZ8SQ8QpZhhs10CQQDILEcf80w3FlX9RgRu
VG6zFDcEKkoazMRAmP8TJAsbqIitgHWyQYF92cOfAIq+nUVnDPBZEO01j+aofK2l
RZ3PAkBIUW7Oc3KpVt/EfAcgyiPhhHrbj6hB2vsM/TwPnszESP8Openz9wLNDYZV
2bZ9WGk0E0JhMQ+Edljthvp5a5rFAkAivLRXEhSe1qxzeGwabWKMhyyI94HGptRD
1YkmXDHlSdj2Kv3BwmZjXZ/5/tEVBRvfJzqqaiqQCfngMUq9DJi3AkA3UmkMCyfw
0PK8r4wqhXvso4rOUT70fpKVimojaeMzqxWpZ2tWaE6wX5jDfgpqK347VQ+XkI2W
7CZssl4WdZ5X
-----END PRIVATE KEY-----";
    public function index(TestRequest $request)
    {
        
    }
    public function publish()
    {
        for ($i=0;$i<100;$i++) {
            $data = ['publish'=>'order'.random_int(1, 10000)];
            $id = TestModel::createOne($data);
            RabbitmqHelper::getInstance()->push($id, 'test_model');
        }
    }

    public function excel()
    {
        dd(RabbitmqHelper::getInstance()->getQueues());
    }
    public function getNameList(TestRequest $request)
    {
        return new Paginate(TestModel::getNameList($request));
    }
    // 假量占比 权重20分  假量人数/总注册人数
    // 档位1-6挡   1挡20分（<6%） 2挡16分（<7.5%） 3挡12分（<9%） 4挡8分（<10.5%） 5挡4分  （<12%） 6档0分（>12%）

    // 人均盈利金额 权重30分  （总充值-总提现）/总注册人数90
    // 档位1-6挡   1挡30分（>30元） 2挡24分（20-30元） 3挡18分（10-20元） 4挡12分（5-10元） 5挡6分（0-5元） 6档0分（<0元）

    // 人均充值次数： 权重15分  总充值人数/总注册人数45
    // 档位1-6挡   1挡15分（>0.3次） 2挡12分（0.2-0.3次） 3挡9分（0.1-0.2次） 4挡6分（0.05-0.1次）挡3分（0-0.05次）6档0分（<0次）

    // 人均活跃天数  ：权重15分   总活跃天数/总注册人数
    // 档位1-6挡   1挡15分（>1天） 2挡12分（0.7-1天） 3挡9分（0.4-0.7天） 4挡6分（0.2-0.4天） 5挡3分（0-0.2天）6档0分（<0天）

    // 人均直播间停留时间： 权重15分  总直播间停留时间/总注册人数
    // 档位1-6挡  1挡15分（>30分钟） 2挡12分（20-30分钟） 3挡9分（10-20分钟） 4挡6分（5-10分钟）5挡3分（0-5分钟）6档（<0分钟）

    // 人均进入游戏次数： 权重5分   总进入游戏次数/总注册人数
    // 档位1-6挡   1挡5分（>4次） 2挡4分（3-4次） 3挡3分（2-3次） 4挡2分（1-2次） 5挡1分（0-1次）6挡0分（<0次）
    public function test($name,$content,$level,$uid)
    {
        $telegram = new Telegram('5260548138:AAFJ289kSHto5jAiGlInfK86XpsKcdb0Gjk', '@Message20220323bot');
        $telegram->useGetUpdatesWithoutDatabase();
        dd(Request::sendMessage([
                            'chat_id' => '-1001628469426',
                            'text'    => 
"会员昵称:{$name}
 会员等级:{$level}
 会员id：{$uid}
 发送内容:{$content}",
        ]));
    }
    public function send($name,$content,$level,$uid){
        $telegram = new Telegram('5260548138:AAFJ289kSHto5jAiGlInfK86XpsKcdb0Gjk', '@Message20220323bot');
        $telegram->useGetUpdatesWithoutDatabase();
        dd(Request::sendMessage([
                            'chat_id' => '-1001628469426',
                            'text'    => 
"会员昵称:{$name}
会员等级:{$level}
会员id：{$uid}
发送内容:{$content}",
        ]));
    }
    public function receive(TestRequest $request) {
        $arr = array('客服','冻结','公安','银行卡','警察局','异常','银行','报警','举报','充值');
        $temp = 0;
        foreach ($arr as $key) {
            if(strstr($request->content,$key)!==false) {
                $temp = 1;
                break;
            }
        }
        if ($temp == 1) {
            $this->send($request->name, $request->content, $request->level, $request->uid);
        }
        return $request->content;
    }
    function Post($url,$data) {
        $curl = curl_init();
 
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        if(!$data){
            return 'data is null';
        }
        if(is_array($data))
        {
            $data = json_encode($data);
        }
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_HTTPHEADER,array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length:' . strlen($data),
                'Cache-Control: no-cache',
                'Pragma: no-cache'
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $res = curl_exec($curl);
        $errorno = curl_errno($curl);
        if ($errorno) {
            return $errorno;
        }
        curl_close($curl);
        return $res;
 
    }
     
    public function getSign($data, $md5_key)
    {
        ksort($data);
        $sign_str = '';
        foreach ($data as $key => $val) {
            $sign_str .= $key . '=' . urlencode($val) . '&';
        }

        $sign_str = substr($sign_str,0,-1).$md5_key;
        // dd($sign_str);
        return sha1($sign_str);
    }
    // a=1&b=https%3A%2F%2Fbaidu.com&c=%E6%B5%8B%E8%AF%95&merchant_no=abcdefg&sign_ts=1600764560&sign_type=SHARdKwEC6cjukgyCzWJkYyDYoqBrfwY4ZXb
    // a=1&b=https%3A%2F%2Fbaidu.com&c=%E6%B5%8B%E8%AF%95&merchant_no=abcdefg&sign_ts=1600764560&sign_type=SHARdKwEC6cjukgyCzWJkYyDYoqBrfwY4ZXb
    public function getOrderArray($file)
    {
        $file_path = storage_path($file);
        $fn = fopen($file_path, "r");
        $query_result = [];
        while (! feof($fn)) {
            $row = fgets($fn);
            
            $query_result[] = trim($row);
        }
        if (is_resource($fn)) {
            fclose($fn);
        }
        
        
        return $query_result;
    }
    
    public function findQuery($file, $orderId)
    {
        $file_path = storage_path($file);
        $fn = fopen($file_path, "r");
        $query_result = [];
        while (! feof($fn)) {
            $row = fgets($fn);
            
            //查单返回
            $query = "queryCallbackOrder [Yuzhou]";
            if (strpos($row, $query) !== false && strpos($row, $orderId) !== false) {
                $pattern = '/{.*}/';
                $return  = preg_match($pattern, $row, $query_result);
                fclose($fn);
                break;
            }
        }
        if (is_resource($fn)) {
            fclose($fn);
        }
        
        $result = array_key_exists(0, $query_result) ? $query_result[0] : '';
        return $result;
    }
    public function findCallback($file, $orderId)
    {
        $file_path = storage_path($file);
        $fn = fopen($file_path, "r");
        $query_result = [];
        while (! feof($fn)) {
            $row = fgets($fn);
            
            //查单返回
            $query = "[Yuzhou]--query [success] [{$orderId}]";
            if (strpos($row, $query) !== false) {
                $pattern = '/{.*}/';
                $return  = preg_match($pattern, $row, $query_result);
                fclose($fn);
                break;
            }
        }
        if (is_resource($fn)) {
            fclose($fn);
        }
        
        $result = array_key_exists(0, $query_result) ? $query_result[0] : '';
        return $result;
    }
    /**
     * 拼接获取格式化公钥
     */
    private function getPublicKey($publicKey)
    {
        //公钥
        $formPublicKey = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($publicKey, 64) as $str) {
            $formPublicKey .= $str . "\r\n";
        }
        $formPublicKey .="-----END PUBLIC KEY-----";
        $file = storage_path().'/logs/'.time().'public.log';
        file_put_contents($file, $formPublicKey);
        return $formPublicKey;
    }
    /**
     * 获取格式化私钥
     */
    private function getPrivateKey($privateKey)
    {
        $formPrivateKey = "-----BEGIN PRIVATE KEY-----\r\n";
        foreach (str_split($privateKey, 64) as $str) {
            $formPrivateKey .= $str . "\r\n";
        }
        $formPrivateKey .="-----END PRIVATE KEY-----";
        return $formPrivateKey;
    }
}
