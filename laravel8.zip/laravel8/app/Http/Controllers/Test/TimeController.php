<?php

namespace App\Http\Controllers\Test;

class TimeController extends Apis
{
    function time(){
        
    }
}